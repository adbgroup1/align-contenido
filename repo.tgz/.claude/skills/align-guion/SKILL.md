---
name: align-guion
description: Agente 4 de ALIGN. Escribe los guiones completos escena a escena y crea las filas de la semana en la base Vídeos de Notion.
---

# Agente 4 — Guionista

Lee antes `CLAUDE.md`, `GUIA.md`, la página Aprendizajes, `semanas/<semana>/ideas.md` y `hooks.md`.
Si existe `semanas/<semana>/manager.md` con guiones devueltos, corrige **solo** esos.

## Pasos

1. **Elige las 4 mejores ideas**, cada una con su hook.
2. **Comprueba cada cifra:**
   - busca la fuente con WebSearch; si no la encuentras, quita el dato;
   - los cálculos, hazlos con un script y apunta la fórmula.
3. **Por cada guion, crea una fila en Vídeos** (o actualízala si ya existe):
   - ID (`<semana sin año>-<nn>`, por ejemplo `W47-01`), Título, Estado = `Guion`, Semana, Pilar, Palabra
     clave, Hook, Plataformas = Instagram, YouTube y TikTok.
   - Destino: Curso para CURSO o EMPEZAR; Landing para SISTEMA o COLCHÓN.
   - **Dentro de la página va el guion:**

| # | Tiempo | Texto en pantalla | Animación / visual | Nota |
|---|---|---|---|---|
| 1 | 0,0–2,0 | … | … | HOOK |
| … | … | … | … | RE-HOOK |
| n-1 | … | «Comenta PALABRA…» | … | CTA |
| n | últimos 2–3 s | Marca ALIGN + «Contenido informativo, no es asesoramiento financiero» | … | CIERRE |

   Debajo de la tabla, cuatro secciones:
   - **Datos y fuentes**;
   - **Caption de Instagram/TikTok**;
   - **Título de YouTube**, de 70 caracteres como máximo;
   - **Notas de producción**.

## Reglas

- **Duración:** 20–45 s, con un cambio visual cada 1,5–3 s como mucho.
- **Texto en pantalla:** 12 palabras como máximo por escena.

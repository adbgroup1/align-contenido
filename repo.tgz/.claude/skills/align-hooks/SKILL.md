---
name: align-hooks
description: Agente 3 de ALIGN. Propone hooks de retención y CTAs de palabra clave para las ideas de la semana.
---

# Agente 3 — Hooks y CTA

Lee antes `CLAUDE.md`, `GUIA.md`, la página Aprendizajes y los resúmenes de investigación de los últimos 7 días.

## Qué produces

Escribe `semanas/<semana>/hooks.md`, y para **cada idea** de `ideas.md` pon esto:

### 3 hooks

Cada uno con:
- el patrón (número sorprendente, error común, contraste, pregunta, «nadie te dice»…);
- el texto en pantalla de 0–2 s, de **8 palabras como máximo**;
- lo que se anima en esos 2 s;
- qué pregunta deja abierta y en qué segundo se cierra.

Marca el hook recomendado y explica por qué.

### Re-hook

Entre los segundos 8 y 12.

### CTA

- En pantalla: «Comenta <PALABRA> y te lo mando por DM».
- Versión para YouTube: «…enlace en el comentario fijado».
- Caption: 2–4 líneas, el CTA, 3–5 hashtags y la línea «Contenido informativo, no es asesoramiento
  financiero».

## Reglas

- Que se entienda **sin sonido**.
- Una cifra o un contraste concreto siempre que se pueda.
- **Nunca prometer lo que el vídeo no da**, ni rentabilidades.

---
name: align-feedback
description: Agente 8 de ALIGN. Lee las métricas de los vídeos publicados en Metricool, las pasa a Notion y escribe aprendizajes para los agentes de ideas, hooks y guion.
---

# Agente 8 — Retroalimentación

Lee antes `CLAUDE.md`.

**Si no hay filas de Vídeos con Estado `Programado` o `Publicado` y fecha de subida pasada, termina:**
«Sin vídeos publicados todavía».

## 1 · Datos (solo lectura)

- **Métricas:** con `getAnalyticsAvailableMetrics` y `getAnalyticsDataByMetrics` (blogId `5900765`), saca de
  cada post visualizaciones, retención o tiempo medio visto, likes, comentarios, guardados y compartidos.
- **Pasa a la fila de Notion** Vistas y Retención %.
- **Comentarios con la palabra:** si Metricool los da, a «Comentarios palabra».
- **Estado:**
  - `Publicado` cuando ya haya salido;
  - `Analizado` cuando tenga más de 7 días.

## 2 · Análisis

Compara entre vídeos:
- **Hook:** retención en los primeros segundos.
- **Pilar y palabra clave:** comentarios con la palabra.
- **Formato:** duración y ritmo.
- **Calidad:** guardados, compartidos y preguntas reales.

## 3 · Aprendizajes

Arriba de la página Aprendizajes, en «Reglas vigentes»:
- **Como mucho 3 reglas nuevas o cambiadas por semana.**
- Cada una con su fecha, la evidencia (IDs y métricas) y la acción concreta para los agentes 2, 3 y 4.
- **Con menos de 3 vídeos con datos**, solo observaciones, no reglas.
- Añade un informe corto en «Informes semanales».

---
name: align-produccion
description: Agente 6 de ALIGN. Convierte en vídeo con Remotion los guiones aprobados por el manager (o los que tienen cambios pedidos por Andrés), los sube al repo y los deja listos para revisar en Notion.
---

# Agente 6 — Producción con Remotion

Lee antes `CLAUDE.md` (sobre todo «Renderizar en esta nube») y `GUIA.md`.

## Qué vídeos haces

Las filas de Vídeos con Estado = `Revisión manager OK`, o las que te indique la tarea.

## Por cada vídeo

1. **Lee el guion** dentro de la página de Notion.
2. **Crea la composición:**
   - archivo `videos/src/videos/<ID>.tsx`: 1080×1920, 30 fps, con la duración del guion;
   - regístrala en `videos/src/Root.tsx`, dentro del `<Folder name="Reels">`, con `id="<ID>"`;
   - **reutiliza** las escenas de `Scenes.tsx` y los colores de `brand.ts`;
   - si creas una escena reutilizable, muévela a `Scenes.tsx`.
3. **Respeta el guion al pie de la letra:** textos, tiempos, hook, re-hook, CTA y cierre. No inventes cifras.
4. **Comprueba el código:** `cd videos && npx tsc --noEmit`.
5. **Renderiza** a `media/<semana>/<ID>.mp4` con los flags de CLAUDE.md.
6. **Miniatura:**
   `npx remotion still src/index.ts <ID> ../media/<semana>/<ID>.jpg --frame=<frame del hook>`, con los mismos
   flags de navegador.
7. **Control de calidad.** Saca 4 fotogramas (hook, mitad, CTA y cierre) con `remotion still` en `/tmp` y
   míralos. Comprueba que:
   - el texto se lee y no se corta;
   - hay al menos 90 px de margen a los lados;
   - no hay nada importante en los 250 px de abajo.
   Si algo falla, corrige y vuelve a renderizar.
8. **Commit y push**, para que exista la URL pública.
9. **Actualiza la fila en Notion:**
   - Estado = `Tu revisión`;
   - «Enlace vídeo» = la URL de raw.githubusercontent;
   - añade al principio de la página el vídeo incrustado (bloque de vídeo con esa URL).

## Reglas

- **No instales paquetes nuevos.**
- Sin música ni imágenes con copyright.
- **Si un vídeo falla 3 veces**, apúntalo en «Nota del manager» y sigue con el siguiente.

---
name: align-investigacion
description: Agente 1 de ALIGN. Investiga vídeos cortos virales (formato motion de cualquier nicho y de finanzas personales) y guarda una ficha de cada uno en la base Investigación de Notion.
---

# Agente 1 — Investigación de virales

Lee antes `CLAUDE.md` y `GUIA.md`.

## Qué buscar (8–12 vídeos nuevos por noche)

- **6–8 vídeos de formato motion, de cualquier nicho:** tipografía cinética, explicativos con gráficos, sin
  cara o casi. Por ejemplo: ciencia, historia, datos, productividad, negocios.
- **2–4 vídeos de finanzas personales e inversión**, en español e inglés.
- **Viral** quiere decir muchas visualizaciones para el tamaño del canal (≥5× su media) o más de 500.000 en
  las últimas 4 semanas.

## Cómo buscar

- Usa WebSearch y WebFetch.
- **YouTube Shorts es la fuente principal:** las páginas son públicas.
- **Instagram y TikTok:** solo lo público vía buscador (artículos de tendencias, recopilatorios). Sin iniciar
  sesión ni saltarte bloqueos.
- **Antes de añadir un vídeo**, busca su enlace en la base Investigación para no repetirlo.

## Qué guardas

**Una fila por vídeo** en la base Investigación (`collection://418cc81e-aca2-811d-821b-000b03502156`):
- **Vídeo:** el título.
- **Propiedades:** Enlace, Plataforma, Nicho, Vistas, Fecha (hoy), Patrón de hook, Por qué funciona y
  Adaptable a ALIGN.
- **Dentro de la página:**
  - duración y ritmo (escenas y segundos por escena);
  - el hook de 0–3 s, con el texto exacto y lo que se ve;
  - la estructura escena a escena;
  - los recursos visuales;
  - el CTA;
  - cómo adaptarlo a ALIGN.

## Resumen del día

Crea `semanas/investigacion/<AAAA-MM-DD>.md` con:
- los 3 patrones de hook que más se repiten;
- los 3 recursos visuales que más se repiten;
- las 2 mejores oportunidades para ALIGN.

Después, haz commit y push.
